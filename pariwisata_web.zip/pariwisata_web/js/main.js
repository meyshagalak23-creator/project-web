// Navbar shrink on scroll + active year & simple signup handler
document.addEventListener("DOMContentLoaded", () => {
    const navbar = document.querySelector(".custom-navbar");
    const yearSpan = document.getElementById("year");
    const signupForm = document.getElementById("signupForm");
    const signupSuccess = document.getElementById("signupSuccess");
  
    // Tahun di footer
    if (yearSpan) {
      yearSpan.textContent = new Date().getFullYear();
    }
  
    // Navbar scroll effect
    const handleScroll = () => {
      if (!navbar) return;
      if (window.scrollY > 40) {
        navbar.classList.add("navbar-scrolled");
      } else {
        navbar.classList.remove("navbar-scrolled");
      }
    };
  
    handleScroll();
    window.addEventListener("scroll", handleScroll);
  
    // Simulasi submit form Sign Up
    if (signupForm && signupSuccess) {
      signupForm.addEventListener("submit", (e) => {
        e.preventDefault();
  
        // Di sini nanti bisa diganti dengan AJAX / fetch ke backend
        signupSuccess.classList.remove("d-none");
  
        // Optional: reset form setelah "berhasil"
        signupForm.reset();
      });
    }
  });
  